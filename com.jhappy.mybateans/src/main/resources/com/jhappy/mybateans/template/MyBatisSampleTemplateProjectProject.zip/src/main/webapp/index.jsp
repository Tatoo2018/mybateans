<%@page import="com.sample.dbmodel.Todo"%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    SimpleDateFormat sdfsecond = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    SimpleDateFormat sdfminute = new SimpleDateFormat("yyyy/MM/dd");
%>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css" /> 
    </head>

    <body>

        <form action="${pageContext.request.contextPath}/" method="GET">
            Title: <input type="text" class="search-text" name="title" value="<%= request.getParameter("title") != null ? request.getParameter("title") : ""%>">
            <button type="submit" class="button">
                Search
            </button>     
        </form>


        <a href="${pageContext.request.contextPath}/add" class="editbutton addbutton button">＋Add</a>

        <table border="1" class="table">
            <tr>
                <th></th>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>DueDate</th>
                <th>IsCompleted</th>
                <th>CreatedAt</th>

            </tr>

            <%
                List<Todo> list = (List<Todo>) request.getAttribute("todos");
                if (list != null) {
                    for (Todo c : list) {
            %>
            <tr>
                <td class="idcolumn">

                    <a class="editbutton button" href="${pageContext.request.contextPath}/edit?id=<%= c.getId()%>">Edit</a>

                    <form style="margin:0" action="${pageContext.request.contextPath}/delete" method="POST" >
                        <button type="submit" class="delbutton button">Delete</button>
                        <input type="hidden" name="id" value="<%= c.getId()%>" />
                    </form>


                </td>
                <td><%= c.getId()%></td>
                <td><%= c.getTitle()%></td>
                <td><%= c.getDescription()%></td>
                <td><%= c.getDueDate() != null ? sdfminute.format(c.getDueDate()) : ""%></td>
                <td><%= c.getIsCompleted() == 1 ? "<span style='color:green;'>完了</span>" : "<span style='color:red;'>未完了</span>"%></td>
                <td><%= c.getCreatedAt() != null ? sdfsecond.format(c.getCreatedAt()) : ""%></td>

            </tr>
            <%
                }
            } else {
            %>
            <tr><td colspan="12">No data found.</td></tr>
            <%
                }
            %>
        </table>





        <%
            String isExistDbServer = (String) request.getAttribute("isExistDbServer");
            if ("false".equals(isExistDbServer)) {
        %>
        <div class="messagebox">

            <div class="messageboxmessage">
                Can't connect Database Server
            </div>

            <div class="messageboxsql">     
                Connection failed.<br>
                The database server may be offline,<br>
                or the connection settings might be incorrect.<br>
                Please verify your configuration in <strong>/src/main/resources/mybatis-config.xml</strong> <br>
                or ensure the DB server is running.

                <div style="margin:20px 0 0 0;font-weight: bold;">DB server on NetBeans</div>
                <img src='images/image2.png' style="width:400px;display:block;margin:0 0 20px;border:1px solid gray;"/>

                <div style="font-weight:bold;">Configuration of MyBatis on [/src/main/resources/mybatis-config.xml] </div>
                <img src='images/image1.png' style="width:400px;display:block;border:1px solid gray;"/>
            </div>

        </div>
        <%
            }

        %>


        <%            String isExistTable = (String) request.getAttribute("isExistTable");
            if ("false".equals(isExistTable)) {

        %>

        <div class="messagebox">

            <div class="messageboxmessage">
                TODOS TABLE doesn't exist.<br>
                Please create this table on database.
            </div>

            <div class="messageboxsql">     
                CREATE TABLE todos (<br>
                id INT PRIMARY KEY NOT NULL,<br>
                title VARCHAR(255),<br>
                description VARCHAR(1000),<br>
                due_date DATE,<br>
                is_completed SMALLINT DEFAULT 0 NOT NULL,<br>
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP<br>
                );
            </div>

        </div>

        <%            }
        %>


    </body>
</html>