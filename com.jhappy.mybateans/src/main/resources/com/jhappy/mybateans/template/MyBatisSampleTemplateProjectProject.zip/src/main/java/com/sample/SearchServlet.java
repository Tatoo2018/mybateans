package com.sample;

import com.sample.dbmodel.Todo;
import com.sample.mapper.TodoMapper;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.apache.ibatis.exceptions.PersistenceException;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.*;

@WebServlet(urlPatterns = {"/search", ""})
public class SearchServlet extends HttpServlet {

    private SqlSessionFactory factory;

    @Override
    public void init() throws ServletException {
        try {
            InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
            factory = new SqlSessionFactoryBuilder().build(is);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String title = req.getParameter("title");

        try (SqlSession session = factory.openSession()) {
            TodoMapper mapper = session.getMapper(TodoMapper.class);

            int count = 0;
            try {
                count = mapper.checkTableExists();
            } catch (PersistenceException e) {
                req.setAttribute("isExistDbServer", "false");
                RequestDispatcher rd = req.getRequestDispatcher("/index.jsp");
                rd.forward(req, resp);
                return;
            }

            if (count == 0) {
                req.setAttribute("isExistTable", "false");
            } else {

                List<Todo> list = mapper.findByTitle(title);

                req.setAttribute("todos", list);
            }

            RequestDispatcher rd = req.getRequestDispatcher("/index.jsp");
            rd.forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        Todo todo = new Todo();
        todo.setTitle(req.getParameter("title"));
        todo.setDescription(req.getParameter("description"));
        String dueDateStr = req.getParameter("dueDate");
        if (dueDateStr != null && !dueDateStr.isEmpty()) {
            todo.setDueDate(java.sql.Date.valueOf(dueDateStr));
        }

        String isCompStr = req.getParameter("isCompleted");
        todo.setIsCompleted((isCompStr != null && isCompStr.equals("1")) ? 1 : 0);

        String idStr = req.getParameter("id");

        try (SqlSession session = factory.openSession()) {
            TodoMapper mapper = session.getMapper(TodoMapper.class);

            if (idStr == null || idStr.trim().isEmpty()) {

                Integer maxId = mapper.getMaxId();
                int nextId = (maxId == null) ? 1 : maxId + 1;
                todo.setId(nextId);

                mapper.insert(todo);
            } else {
                todo.setId(Integer.valueOf(idStr.trim()));
                mapper.update(todo);
            }

            session.commit();
        }

        resp.sendRedirect(req.getContextPath() + "/");
    }

}
