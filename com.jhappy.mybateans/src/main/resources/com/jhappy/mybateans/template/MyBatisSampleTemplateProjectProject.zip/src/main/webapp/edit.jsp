<%@page import="com.sample.dbmodel.Todo"%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ taglib prefix="my" tagdir="/WEB-INF/tags" %>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/style.css" /> 
    </head>

    <body>
        <div clas="form-title">
            <a class="link" href="${pageContext.request.contextPath}/">&lt;&lt;Go To Search Screen</a>
        </div>
        <form action="${pageContext.request.contextPath}/" method="POST" class="formbox">
            <div class="form-title">Update Todo</div>

            <div class="row"> 
                <div class="formlabel">ID:</div>
                <div class="forminput">
                    <input type="hidden" name="id" value="${todo.id}">
                    ${todo.id}
                </div>
            </div>

            <div class="row"> 
                <div class="formlabel">Title:</div>
                <div class="forminput">
                    <input type="text" name="title" value="${todo.title}" required>  
                </div>
            </div>

            <div class="row"> 
                <div class="formlabel">Description:</div>
                <div class="forminput">
                    <textarea type="text" class="descriptiontext" name="description">${todo.description}</textarea>
                </div>
            </div>

            <div class="row"> 
                <div class="formlabel">Due Date:</div>
                <div class="forminput">
                    <input type="date" name="dueDate" value="${todo.dueDate}">
                </div>
            </div>

            <div class="row"> 
                <div class="formlabel">IsCompleted:</div>
                <div class="forminput">
                    <label>
                        <input type="checkbox" name="isCompleted" value="1" ${todo.isCompleted == 1 ? 'checked' : ''}>
                        Done
                    </label>
                </div>
            </div>

            <input type="submit" class="button savebutton" value="Update Data">
        </form>

    </body>
</html>