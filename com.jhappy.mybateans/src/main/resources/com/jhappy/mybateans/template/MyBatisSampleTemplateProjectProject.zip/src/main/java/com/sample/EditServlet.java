package com.sample;

import com.sample.dbmodel.Todo;
import com.sample.mapper.TodoMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

@WebServlet("/edit")
public class EditServlet extends HttpServlet {

    private SqlSessionFactory factory;

    @Override
    public void init() throws ServletException {
        try {
            InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
            factory = new SqlSessionFactoryBuilder().build(is);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String idStr = req.getParameter("id");

        try (SqlSession session = factory.openSession()) {

            TodoMapper mapper = session.getMapper(TodoMapper.class);

            List<Todo> list = mapper.findById(Integer.valueOf(idStr));

            if (!list.isEmpty()) {

                req.setAttribute("todo", list.get(0));

            }
        }
        req.getRequestDispatcher("/edit.jsp").forward(req, resp);
    }
}
