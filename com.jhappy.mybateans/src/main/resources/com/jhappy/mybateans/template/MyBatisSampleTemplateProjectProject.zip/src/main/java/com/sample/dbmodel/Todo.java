package com.sample.dbmodel;

import java.sql.Date;
import java.sql.Timestamp;

public class Todo {
    private Integer id;           // PRIMARY KEY
    private String title;         // VARCHAR(255)
    private String description;   // VARCHAR(1000)
    private Date dueDate;         // DATE (java.sql.Date)
    private int isCompleted;      // SMALLINT (0:未完了, 1:完了)
    private Timestamp createdAt;  // TIMESTAMP

    // コンストラクタ（空）
    public Todo() {}

    // Getter / Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public int getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(int isCompleted) {
        this.isCompleted = isCompleted;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}